# This is empty so trying to fetch the fixer class gives an AttributeError
