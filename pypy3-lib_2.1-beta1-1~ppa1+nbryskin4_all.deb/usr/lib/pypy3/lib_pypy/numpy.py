raise ImportError(
    "The 'numpy' module of PyPy is in-development and not complete. "
    "To try it out anyway, you can either import from 'numpypy', "
    "or just write 'import numpypy' first in your program and then "
    "import from 'numpy' as usual.")
