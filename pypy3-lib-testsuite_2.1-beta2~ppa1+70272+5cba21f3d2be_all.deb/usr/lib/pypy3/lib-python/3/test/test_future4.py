from __future__ import unicode_literals

import unittest
from test import support

def test_main():
    pass

if __name__ == "__main__":
    test_main()
