def dummyfunc(*args, **kwargs):
    raise NotImplementedError("non-implemented ctypes function")

resize = dummyfunc

