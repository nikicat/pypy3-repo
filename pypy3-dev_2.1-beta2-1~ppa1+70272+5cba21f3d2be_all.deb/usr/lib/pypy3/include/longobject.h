
/* Int object interface */

#ifndef Py_LONGOBJECT_H
#define Py_LONGOBJECT_H
#ifdef __cplusplus
extern "C" {
#endif

#define PyLong_AS_LONG(op) PyLong_AsLong(op)

#ifdef __cplusplus
}
#endif
#endif /* !Py_LONGOBJECT_H */
